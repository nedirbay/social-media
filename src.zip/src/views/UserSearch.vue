<template>
  <div class="max-w-2xl mx-auto space-y-8">
    <button
      @click="$router.back()"
      class="text-gray-600 dark:text-gray-300 hover:text-gray-900 dark:hover:text-white flex items-center"
    >
      <svg
        class="w-5 h-5 mr-1"
        fill="none"
        stroke="currentColor"
        viewBox="0 0 24 24"
      >
        <path
          stroke-linecap="round"
          stroke-linejoin="round"
          stroke-width="2"
          d="M15 19l-7-7 7-7"
        />
      </svg>
      Back
    </button>

    <div class="text-center">
      <h1 class="text-3xl font-bold text-gray-900 dark:text-white">
        Search {{ platformName }} Users
      </h1>
      <p class="mt-2 text-gray-600 dark:text-gray-300">
        Enter a username to search
      </p>
    </div>

    <div class="space-y-4">
      <input
        v-model="username"
        type="text"
        placeholder="Enter username"
        class="search-input"
        @keyup.enter="searchUser"
      />
      <button
        @click="searchUser"
        class="btn-primary w-full"
        :disabled="!username"
      >
        Search
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import axios from "axios";
import { ref, computed } from "vue";
import { useRouter, useRoute } from "vue-router";

const router = useRouter();
const route = useRoute();
const username = ref("");

const platformName = computed(() => {
  const platform = route.params.platform as string;
  return platform.charAt(0).toUpperCase() + platform.slice(1);
});

const fetchUserDetails = async (row: any) => {
  if (row.details) return;
  try {
    const response = await axios.get(
      `https://jsonplaceholder.typicode.com/users/${username.value}`
    );
    row.details = response.data;
  } catch (error) {
    console.error("Error fetching details:", error);
  }
};

const searchUser = () => {
  if (username.value) {
    router.push(`/profile/${route.params.platform}/${username.value}`);
  }
};
</script>