import { ref } from "vue";

export const isDarkMode = ref(false);